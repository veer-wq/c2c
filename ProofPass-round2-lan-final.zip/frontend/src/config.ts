// Backend base URL. Override with a Vite env var (VITE_API_BASE_URL) if the
// backend isn't running on the default host/port.
export const API_BASE_URL: string =
  (import.meta as any).env?.VITE_API_BASE_URL || "http://127.0.0.1:8000";

// Set VITE_WALLET_PUBLIC_URL to the laptop's LAN URL (for example,
// http://192.168.x.x:5173) when `window.location` is localhost. The QR link
// always points at this public wallet URL and never includes a hard-coded IP.
export const WALLET_PUBLIC_URL: string =
  (import.meta as any).env?.VITE_WALLET_PUBLIC_URL || window.location.origin;

// Demo identity used throughout the flow. This is a hackathon demo, so
// there's a single hardcoded student the Issuer panel creates a credential
// for, and the Wallet loads.
export const DEMO_STUDENT_ID = "DEMO001";
export const DEMO_STUDENT_NAME = "Vijay Rohra";
export const DEMO_ISSUER = "VIT Vellore";
